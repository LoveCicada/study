
- media detect library
```
use for luna and mpc, maybe nonlinear
```

- Linux
```

```

- Windows
```

```

- error code
```
if interface return code greater than 0, it will be fail.
only return 0 is success
```
- 
```
Success = 0,    
InitLibraryFail = 1,

```

- depends sdk library
```
libVXCutlistV2Plus.so
we can target at cmakelists.txt,
actually is implicit link
```
- info
```
1. file detail
2. video detail
3. audio detail
4. system stream detail
5. data stream detail
```